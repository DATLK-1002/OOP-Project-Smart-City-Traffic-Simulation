package model.vehicle;
package model.Vehicle;

public enum VehicleState {
    MOVING,
    STOPPED,
    WAITING,
    OVERTAKING
}